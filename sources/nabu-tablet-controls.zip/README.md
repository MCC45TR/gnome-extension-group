# Nabu Tablet Controls

Native GNOME Shell Quick Settings and Plasma integrations for Xiaomi Pad 5
(Nabu) hardware controls. The GNOME extension keeps the stock GNOME visual
language and uses GNOME's Quick Settings, slider, preferences and GSettings
components instead of replacing Shell UI.

The GNOME extension UUID is `nabulinuxproject@mcc45tr`. Its independently
installable Fedora package is built by
[`MCC45TR/gnome-extension-group`](https://github.com/MCC45TR/gnome-extension-group).

Hardware operations are delegated to narrowly scoped helpers installed by the
Nabu core package. Privileged USB role changes go through polkit; the extension
does not write privileged sysfs nodes directly.

## License

GPL-3.0-or-later. The bundled uMTP-Responder component retains its own upstream
copyright and license notices.
